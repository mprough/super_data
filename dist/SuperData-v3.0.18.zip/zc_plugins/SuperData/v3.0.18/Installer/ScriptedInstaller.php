<?php

declare(strict_types=1);

if (!defined('IS_ADMIN_FLAG')) {
    die('Illegal Access');
}

/**
 * @author: torvista
 * @link: https://github.com/torvista/Zen_Cart-Structured_Data
 * @license https://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version ZenExpert 20 Dec 2025
 * @version markbrittain 20 Dec 2025
 */
use Zencart\PluginSupport\ScriptedInstaller as ScriptedInstallBase;

class ScriptedInstaller extends ScriptedInstallBase
{
    protected string $configPageKey = 'configSuperData';

    protected string $configGroupTitle = 'SuperData';

    protected int $cgi;

    protected string $template_dir;

    public string $pluginKey = 'SuperData';

    public string $version = '3.0.18';

    /**
     * Compatibility implementation for Zen Cart 2.0.x, which does not yet
     * provide the getOrCreateConfigGroupId() installer helper.
     */
    protected function getOrCreateConfigGroupId(string $config_group_title, string $config_group_description, ?int $sort_order = 1): int
    {
        $config_group_title = zen_db_input($config_group_title);
        $config_group_description = zen_db_input($config_group_description);
        $sort_order = (int)($sort_order ?? 0);

        $result = $this->dbConn->Execute(
            "SELECT configuration_group_id
               FROM " . TABLE_CONFIGURATION_GROUP . "
              WHERE configuration_group_title = '$config_group_title'
              LIMIT 1"
        );
        if (!$result->EOF) {
            return (int)$result->fields['configuration_group_id'];
        }

        $this->executeInstallerSql(
            "INSERT INTO " . TABLE_CONFIGURATION_GROUP . "
                (configuration_group_title, configuration_group_description, sort_order, visible)
             VALUES
                ('$config_group_title', '$config_group_description', $sort_order, 1)"
        );

        $result = $this->dbConn->Execute(
            "SELECT configuration_group_id
               FROM " . TABLE_CONFIGURATION_GROUP . "
              WHERE configuration_group_title = '$config_group_title'
              LIMIT 1"
        );
        $cgi = (int)($result->fields['configuration_group_id'] ?? 0);

        if ($cgi > 0 && $sort_order === 0) {
            $this->executeInstallerSql(
                "UPDATE " . TABLE_CONFIGURATION_GROUP . "
                    SET sort_order = $cgi
                  WHERE configuration_group_id = $cgi
                  LIMIT 1"
            );
        }

        return $cgi;
    }

    /**
     * Compatibility implementation spanning the Zen Cart 2.0.x and 2.1+
     * deleteConfigurationGroup() signatures.
     */
    public function deleteConfigurationGroup($group, bool $cascadeDeleteKeysToo = false): int
    {
        if (is_numeric($group)) {
            $cgi = (int)$group;
        } else {
            $group_title = zen_db_input($group);
            $result = $this->dbConn->Execute(
                "SELECT configuration_group_id
                   FROM " . TABLE_CONFIGURATION_GROUP . "
                  WHERE configuration_group_title = '$group_title'
                  LIMIT 1"
            );
            $cgi = (int)($result->fields['configuration_group_id'] ?? 0);
        }

        if ($cgi < 1) {
            return 0;
        }

        if ($cascadeDeleteKeysToo) {
            $this->executeInstallerSql(
                "DELETE FROM " . TABLE_CONFIGURATION . " WHERE configuration_group_id = $cgi"
            );
        }

        $this->executeInstallerSql(
            "DELETE FROM " . TABLE_CONFIGURATION_GROUP . " WHERE configuration_group_id = $cgi"
        );

        return $this->dbConn->affectedRows();
    }

    /**
     * @return bool
     */
    protected function executeInstall(): bool
    {
        global $template_dir;
        $this->template_dir = $template_dir;

        if (!$this->checkForConflictingFiles()) {
            return false;
        }

        $this->cgi = $this->getOrCreateConfigGroupId($this->configGroupTitle, $this->configGroupTitle, null);
        $this->ensureCountryOfOriginField();

        // -----
        // If the plugin's configuration settings aren't present, add them now.
        //
        $this->executeInstallerSql(
            "INSERT IGNORE INTO " . TABLE_CONFIGURATION . "
                (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function)
             VALUES
                ('SuperData version', 'PLUGIN_SUPERDATA_VERSION', '3.0.18', 'Installed version. Check <a href=\"https://github.com/mprough/super_data\" target=\"_blank\" rel=\"noopener\">SuperData on GitHub</a> for the newest release because GitHub updates can appear before Zen Cart Plugin Library approval is complete.', $this->cgi, 0, 'zen_cfg_select_option(array(\'3.0.18\'),'),
                ('Enable SuperData generation', 'PLUGIN_SUPERDATA_ENABLE', 'true', 'Enable the SuperData plugin code', $this->cgi, 1, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
                ('Enable Schema markup', 'PLUGIN_SUPERDATA_SCHEMA_ENABLE', 'true', 'Show Schema markup?<br>Shows JSON-LD blocks for Organisation and Breadcrumbs on all pages, Product on product pages.', $this->cgi, 2, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
                ('Enable Facebook-Open Graph markup', 'PLUGIN_SUPERDATA_FOG_ENABLE', 'true', 'Show Facebook-Open Graph markup?<br>Shows Facebook og tags on all pages with additional product-specific tags on product pages.', $this->cgi, 3, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
                ('Enable Twitter Card markup', 'PLUGIN_SUPERDATA_TWITTER_CARD_ENABLE', 'true', 'Show Twitter Card markup?<br>Shows on all pages.', $this->cgi, 4, 'zen_cfg_select_option(array(\'true\', \'false\'),'),

                ('Facebook Application ID', 'PLUGIN_SUPERDATA_FOG_APPID', '', 'Enter your Facebook application ID (<a href=\"https://developers.facebook.com/docs/development/create-an-app\" target=\"_blank\">Get an application ID</a>).', $this->cgi, 5, NULL),
                ('Facebook Admin ID (optional)', 'PLUGIN_SUPERDATA_FOG_ADMINID', '', 'Enter the Admin ID(s) of the Facebook user(s) that administer your Facebook fan page separated by commas. <a href=\"https://business.facebook.com\" target=\"_blank\">Facebook Business</a>.', $this->cgi, 6, null),
                ('Facebook Page (optional)', 'PLUGIN_SUPERDATA_FOG_PAGE', '', 'Enter the full url/link to your facebook page e.g.: https://www.facebook.com/zencart/.', $this->cgi, 7, null),

                ('Organization Type', 'PLUGIN_SUPERDATA_ORGANIZATION_TYPE', 'Organization', 'If you have a physical store and want to specify it, choose LocalBusiness instead of the generic Organization.', $this->cgi, 8, 'zen_cfg_select_option(array(\'Organization\', \'LocalBusiness\', \'OnlineBusiness\'),'),

                ('LocalBusiness Type', 'PLUGIN_SUPERDATA_LOCAL_BUSINESS_TYPE', 'Store', 'This option is used ONLY if Organization Type is set to LocalBusiness. The list is not complete because there is a large number of options. Choose the one that fits best, or choose Store as a generic option.', $this->cgi, 9, 'zen_cfg_select_option(array(\'Store\', \'ShoppingCenter\', \'BikeStore\', \'BookStore\', \'ClothingStore\', \'ComputerStore\', \'ConvenienceStore\', \'DepartmentStore\', \'ElectronicsStore\', \'Florist\', \'FurnitureStore\', \'GardenStore\', \'GroceryStore\', \'HardwareStore\', \'HobbyShop\', \'HomeGoodsStore\', \'JewelryStore\', \'LiquorStore\', \'MensClothingStore\', \'MobilePhoneStore\', \'MovieRentalStore\', \'MusicStore\', \'OfficeEquipmentStore\', \'OutletStore\', \'PawnShop\', \'PetStore\', \'ShoeStore\', \'SportingGoodsStore\', \'TireShop\', \'ToyStore\', \'WholesaleStore\'),'),

                ('Legal Name (Schema, optional)', 'PLUGIN_SUPERDATA_LEGAL_NAME', '', 'The registered company name.', $this->cgi, 15, null),
                ('Dun & Bradstreet DUNS number (Schema, optional)', 'PLUGIN_SUPERDATA_DUNS', '', 'The Dun & Bradstreet DUNS number for identifying an organization or a business person.', $this->cgi, 16, null),

                ('Name (Schema)', 'PLUGIN_SUPERDATA_LOCAL_BUSINESS_NAME', '', 'If you chose LocalBusiness, enter the name (this can be different than your Legal Name).', $this->cgi, 20, null),
                ('Short Description (Schema)', 'PLUGIN_SUPERDATA_DESCRIPTION', '', 'Enter a short description of your business.', $this->cgi, 21, null),
                ('Business Image (Schema, optional)', 'PLUGIN_SUPERDATA_PROPERTY_IMAGE', '', 'Image for Organization, OnlineBusiness, OnlineStore, or LocalBusiness markup. Enter one complete image URL or multiple URLs separated by commas. If blank, SuperData uses the configured Logo so the Schema image field is not missing.', $this->cgi, 25, null),

                ('Logo (Schema)', 'PLUGIN_SUPERDATA_LOGO', '', 'Enter the complete url to your logo image.', $this->cgi, 30, null),

                ('Price Range (Schema)', 'PLUGIN_SUPERDATA_PRICE_RANGE', '', 'Use currency symbols to indicate your price range. The standard is a scale from 1 to 4, where 1 stands for inexpensive, 2 for moderate/average, 3 for expensive and 4 means luxury. Example: $$.', $this->cgi, 31, null),

                ('Street Address (Schema/OG)', 'PLUGIN_SUPERDATA_STREET_ADDRESS', '', 'Enter the business street address.', $this->cgi, 35, null),
                ('City (Schema/OG)', 'PLUGIN_SUPERDATA_LOCALITY', '', 'Enter the business town/city.', $this->cgi, 40, null),
                ('State (Schema/OG)', 'PLUGIN_SUPERDATA_REGION', '', 'Enter the business state/province.', $this->cgi, 45, null),
                ('Postal Code (Schema/OG)', 'PLUGIN_SUPERDATA_POSTALCODE', '', 'Enter the business postal code/zip', $this->cgi, 50, null),
                ('Country (Schema/OG)', 'PLUGIN_SUPERDATA_COUNTRYNAME', '', 'Enter the country <a href=\"https://en.wikipedia.org/wiki/ISO_3166-1\" target=\"_blank\">2 letter ISO code</a>', $this->cgi, 55, null),
                ('Email (Schema, optional)', 'PLUGIN_SUPERDATA_EMAIL', '', 'Enter your Customer Service email address (lower case).', $this->cgi, 60, null),
                ('Telephone (Schema)', 'PLUGIN_SUPERDATA_TELEPHONE', '', 'Enter the Customer Service phone number in international format eg.: +1-330-871-4357. The format (spaces/dashes) is not important.', $this->cgi, 65, null),
                ('Fax (Schema, optional)', 'PLUGIN_SUPERDATA_FAX', '', 'Enter the Customer Service fax number in international format e.g. +1-877-453-1304). The format (spaces/dashes) is not important.', $this->cgi, 70, null),

                ('Available Languages (Schema, optional)', 'PLUGIN_SUPERDATA_AVAILABLE_LANGUAGE', '', 'Languages spoken (for Schema contact point). Enter the language\'s name in English, separated by commas. If omitted, the language defaults to English.', $this->cgi, 75, null),

                ('Locales (OG)', 'PLUGIN_SUPERDATA_FOG_LOCALES', '', 'Enter a comma-separated list of the database language_id and equivalent locale for each defined language e.g.: 1,en_GB,2,es_ES, etc. (no spaces).<br>Separate the parameters with commas.', $this->cgi, 80, null),

                ('Area Served (Schema-Customer Service, optional)', 'PLUGIN_SUPERDATA_AREA_SERVED', '', 'The geographical region served (<a href=\"https://schema.org/areaServed\" target=\"_blank\">further details here</a>).<br>If omitted, the area is assumed to be global.)', $this->cgi, 85, null),

                ('Hours Available (Schema-Customer Service, optional)', 'PLUGIN_SUPERDATA_HOURS', '', 'Customer service working hours (<a href=\"https://schema.org/hoursAvailable\" target=\"_blank\">further details here</a>).<br>If omitted, it will be skipped.)<br>Supports simple and complex scenarios.<br><strong>REQUIREMENTS:</strong> days are listed first, using 3-letter English abbreviation and separated with a comma. Semicolon is used as delimiter between days and times. Times are entered in 24-hour format with a minus indicating range. Split shifts are separated with a comma. Different rules are separated with a pipe.<br>Examples:<br><strong>Simple:</strong> Mon,Tue,Wed,Thu,Fri;09:00-17:00<br><strong>Weekend different:</strong> Mon,Tue,Wed,Thu,Fri;09:00-17:00|Sat;10:00-14:00<br><strong>Split Shift (Lunch break):</strong> Mon,Tue,Wed,Thu,Fri;09:00-12:00,13:00-17:00<br><strong>Complex:</strong> Mon,Wed,Fri;09:00-17:00|Tue,Thu;09:00-12:00,13:00-17:00|Sat;10:00-12:00', $this->cgi, 90, null),

                ('Accepted Payment Methods (Schema)', 'PLUGIN_SUPERDATA_ACCEPTED_PAYMENT_METHODS', 'ByBankTransferInAdvance, ByInvoice, Cash, CheckInAdvance, COD, DirectDebit, GoogleCheckout, PayPal, PaySwarm, AmericanExpress, DinersClub, Discover, JCB, MasterCard, VISA', 'List/delete as applicable the <a href=\"https://www.heppnetz.de/ontologies/goodrelations/v1#PaymentMethod\" target=\"_blank\">accepted payment methods</a>. e.g. ByBankTransferInAdvance, ByInvoice, Cash, CheckInAdvance, COD, DirectDebit, GoogleCheckout, PayPal, PaySwarm, AmericanExpress, DinersClub, Discover, JCB, MasterCard, VISA.', $this->cgi, 95, null),

                ('Tax ID (Schema, optional)', 'PLUGIN_SUPERDATA_TAXID', '', 'The Tax/Fiscal ID of the business (e.g. the TIN in the US or the CIF in Spain).', $this->cgi, 100, null),
                ('VAT Number (Schema, optional)', 'PLUGIN_SUPERDATA_VATID', '', 'Value-added Tax ID of the business.', $this->cgi, 105, null),

                ('Profile/Social Pages (Schema-sameAs, optional)', 'PLUGIN_SUPERDATA_SAMEAS', '', 'Enter a list of URLs to other (NOT Facebook, Twitter or Google Plus) profile or social pages related to your business (e.g. Instagram, TikTok, LinkedIn, Dun & Bradstreet, Yelp etc.).<br>Separate the URLs with commas.', $this->cgi, 110, null),

                ('Product Shipping Area (Schema, optional)', 'PLUGIN_SUPERDATA_ELIGIBLE_REGION', '', 'Area to which you ship products.<br >Use the ISO 3166-1 (ISO 3166-1 alpha-2) or ISO 3166-2 code, or the GeoShape for the geo-political region(s).', $this->cgi, 115, null),

                ('Currency (Schema/OG)', 'PLUGIN_SUPERDATA_PRICE_CURRENCY', '', 'Enter the currency code of the product price e.g.: EUR.', $this->cgi, 120, null),
                ('Product price tax mode', 'PLUGIN_SUPERDATA_PRODUCT_PRICE_TAX_MODE', 'Never', '<strong>Never:</strong> Publish product prices without tax.<br><strong>Always:</strong> Add the tax rate Zen Cart resolves for the visitor.<br><strong>LoggedInTaxZone:</strong> Add tax only for a logged-in customer when Zen Cart resolves a tax rate for that customer\'s country and zone.', $this->cgi, 121, 'zen_cfg_select_option(array(\'Never\', \'Always\', \'LoggedInTaxZone\'),'),

                ('Product Delivery Time when in stock (Schema)', 'PLUGIN_SUPERDATA_DELIVERYLEADTIME', '', 'Enter the average days from order to delivery when product is in stock (e.g.:2).', $this->cgi, 125, null),

                ('Product Delivery Time when out of stock (Schema)', 'PLUGIN_SUPERDATA_DELIVERYLEADTIME_OOS', '', 'Enter the average days from order to delivery when product is out of stock (e.g.:7).', $this->cgi, 130, null),

                ('Offer validFrom', 'PLUGIN_SUPERDATA_VALID_FROM_ENABLE', 'true', 'Add validFrom to every Offer. SuperData uses the future product available date when present, otherwise the product creation date.', $this->cgi, 131, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
                ('Offer shippingDetails', 'PLUGIN_SUPERDATA_SHIPPING_DETAILS_ENABLE', 'true', 'Add OfferShippingDetails to every product Offer using the destination and delivery times below. Disable only when no product shipping information should be published.', $this->cgi, 132, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
                ('Shipping rate mode', 'PLUGIN_SUPERDATA_SHIPPING_RATE_MODE', 'RateTables', '<strong>RateTables:</strong> Calculate rates for this product from up to five destination tables.<br><strong>Free:</strong> Publish a 0.00 rate only when shipping is genuinely free.<br><strong>FlatRate:</strong> Publish the exact configured charge for every covered product.', $this->cgi, 133, 'zen_cfg_select_option(array(\'RateTables\', \'Free\', \'FlatRate\'),'),
                ('Shipping destination country', 'PLUGIN_SUPERDATA_SHIPPING_COUNTRY', 'US', 'Two-letter ISO 3166-1 destination country, for example US, CA, or GB.', $this->cgi, 134, null),
                ('Shipping flat rate', 'PLUGIN_SUPERDATA_SHIPPING_RATE', '', 'Used only with FlatRate. Enter the exact charge applied to every covered product, for example 5.95.', $this->cgi, 135, null),
                ('Zone 1 rate type', 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_1', 'weight', 'Choose price, weight, or item for this destination table.', $this->cgi, 136, 'zen_cfg_select_option(array(\'price\', \'weight\', \'item\'),'),
                ('Zone 1 country', 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_1', 'US', 'Two-letter destination country. Leave blank to disable this zone.', $this->cgi, 137, null),
                ('Zone 1 regions', 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_1', '', 'Optional comma-separated state or region codes. Leave blank for the whole country.', $this->cgi, 138, null),
                ('Zone 1 rates', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_1', '', 'Inclusive upper-limit:rate pairs, for example 1:5.95,3:7.95,*:9.95.', $this->cgi, 139, null),
                ('Zone 1 handling charge', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_1', '0', 'Optional handling charge added to this zone\'s selected rate.', $this->cgi, 140, null),
                ('Zone 2 rate type', 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_2', 'weight', 'Choose price, weight, or item for this destination table.', $this->cgi, 141, 'zen_cfg_select_option(array(\'price\', \'weight\', \'item\'),'),
                ('Zone 2 country', 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_2', '', 'Two-letter destination country. Leave blank to disable this zone.', $this->cgi, 142, null),
                ('Zone 2 regions', 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_2', '', 'Optional comma-separated state or region codes. Leave blank for the whole country.', $this->cgi, 143, null),
                ('Zone 2 rates', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_2', '', 'Inclusive upper-limit:rate pairs.', $this->cgi, 144, null),
                ('Zone 2 handling charge', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_2', '0', 'Optional handling charge.', $this->cgi, 145, null),
                ('Zone 3 rate type', 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_3', 'weight', 'Choose price, weight, or item for this destination table.', $this->cgi, 146, 'zen_cfg_select_option(array(\'price\', \'weight\', \'item\'),'),
                ('Zone 3 country', 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_3', '', 'Two-letter destination country. Leave blank to disable this zone.', $this->cgi, 147, null),
                ('Zone 3 regions', 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_3', '', 'Optional comma-separated state or region codes. Leave blank for the whole country.', $this->cgi, 148, null),
                ('Zone 3 rates', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_3', '', 'Inclusive upper-limit:rate pairs.', $this->cgi, 149, null),
                ('Zone 3 handling charge', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_3', '0', 'Optional handling charge.', $this->cgi, 150, null),
                ('Zone 4 rate type', 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_4', 'weight', 'Choose price, weight, or item for this destination table.', $this->cgi, 151, 'zen_cfg_select_option(array(\'price\', \'weight\', \'item\'),'),
                ('Zone 4 country', 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_4', '', 'Two-letter destination country. Leave blank to disable this zone.', $this->cgi, 152, null),
                ('Zone 4 regions', 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_4', '', 'Optional comma-separated state or region codes. Leave blank for the whole country.', $this->cgi, 153, null),
                ('Zone 4 rates', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_4', '', 'Inclusive upper-limit:rate pairs.', $this->cgi, 154, null),
                ('Zone 4 handling charge', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_4', '0', 'Optional handling charge.', $this->cgi, 155, null),
                ('Zone 5 rate type', 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_5', 'weight', 'Choose price, weight, or item for this destination table.', $this->cgi, 156, 'zen_cfg_select_option(array(\'price\', \'weight\', \'item\'),'),
                ('Zone 5 country', 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_5', '', 'Two-letter destination country. Leave blank to disable this zone.', $this->cgi, 157, null),
                ('Zone 5 regions', 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_5', '', 'Optional comma-separated state or region codes. Leave blank for the whole country.', $this->cgi, 158, null),
                ('Zone 5 rates', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_5', '', 'Inclusive upper-limit:rate pairs.', $this->cgi, 159, null),
                ('Zone 5 handling charge', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_5', '0', 'Optional handling charge.', $this->cgi, 160, null),
                ('Shipping handling time minimum', 'PLUGIN_SUPERDATA_HANDLING_MIN_DAYS', '0', 'Minimum business days before an order ships.', $this->cgi, 161, null),
                ('Shipping handling time maximum', 'PLUGIN_SUPERDATA_HANDLING_MAX_DAYS', '1', 'Maximum business days before an order ships.', $this->cgi, 162, null),
                ('Shipping transit time minimum', 'PLUGIN_SUPERDATA_TRANSIT_MIN_DAYS', '2', 'Minimum business days in transit.', $this->cgi, 163, null),
                ('Shipping transit time maximum', 'PLUGIN_SUPERDATA_TRANSIT_MAX_DAYS', '7', 'Maximum business days in transit.', $this->cgi, 164, null),

                ('Product Condition (Schema/OG)', 'PLUGIN_SUPERDATA_FOG_PRODUCT_CONDITION', 'new', 'Choose your product\'s condition.', $this->cgi, 165, 'zen_cfg_select_option(array(\'new\', \'used\', \'refurbished\'),'),

                ('Default Product Weight', 'PLUGIN_SUPERDATA_DEFAULT_WEIGHT', '0.5', 'If product has no weight defined, use this value.', $this->cgi, 166, null),

                ('Out of Stock Status', 'PLUGIN_SUPERDATA_OOS_DEFAULT', 'BackOrder', 'The default OOS status if a product is out of stock and has no custom field defined for OOS status.', $this->cgi, 167, 'zen_cfg_select_option(array(\'BackOrder\', \'Discontinued\', \'OutOfStock\', \'PreOrder\', \'PreSale\', \'SoldOut\'),'),
                ('Out of Stock - BackOrder/PreOrder Date', 'PLUGIN_SUPERDATA_OOS_AVAILABILITY_DELAY', '10', 'The OOS BackOrder/PreSales conditions require an availability date.<br>Set the number of days to add to today\'s date, to create a new date.', $this->cgi, 168, null),

                ('Limit - Product Name', 'PLUGIN_SUPERDATA_MAX_NAME', '150', 'The maximum number of characters allowed in a product name.<br>Google permits up to 150.', $this->cgi, 170, null),
                ('Limit - Product Description', 'PLUGIN_SUPERDATA_MAX_DESCRIPTION', '5000', 'The maximum number of characters allowed in a product description.<br>Google permits up to 5000.', $this->cgi, 175, null),

                ('Reviews - Default Review Date', 'PLUGIN_SUPERDATA_REVIEW_DEFAULT_DATE', '2020-09-23 13:48:39', 'In the case of a review having no date set (null), use this date.', $this->cgi, 180, null),
                ('No Review - Add One?', 'PLUGIN_SUPERDATA_REVIEW_USE_DEFAULT', 'true', 'If a product has no reviews, use a default value/dummy review to prevent Google Tool warnings.', $this->cgi, 185, null),
                ('No Review - Average Rating', 'PLUGIN_SUPERDATA_REVIEW_DEFAULT_VALUE', '4', 'Average rating for the default review (1-5).', $this->cgi, 190, null),

                ('Returns - Policy', 'PLUGIN_SUPERDATA_RETURNS_POLICY', 'Finite', 'The type of return policy.', $this->cgi, 250, 'zen_cfg_select_option(array(\'Finite\', \'NotPermitted\', \'Unlimited\'),'),
                ('Returns - Days', 'PLUGIN_SUPERDATA_RETURNS_DAYS', '14', 'In the case of the Finite return policy, the period (days limit) during which the product can be returned.', $this->cgi, 255, null),
                ('Returns - Methods', 'PLUGIN_SUPERDATA_RETURNS_METHOD', 'Mail', 'In the case of the Finite/Unlimited return policies, the method of returning the product.', $this->cgi, 260, 'zen_cfg_select_option(array(\'Kiosk\', \'Mail\', \'Store\'),'),
                ('Returns - Type', 'PLUGIN_SUPERDATA_RETURNS_TYPE', 'FreeReturn', 'The type of fee for returns. Ignored when returns are not permitted.', $this->cgi, 265, 'zen_cfg_select_option(array(\'FreeReturn\', \'OriginalShippingFees\', \'RestockingFees\', \'ReturnFeesCustomerResponsibility\', \'ReturnShippingFees\'),'),
                ('Returns - Refund Type', 'PLUGIN_SUPERDATA_RETURNS_REFUND_TYPE', 'FullRefund', 'Refund provided for an accepted return. Choose FullRefund for a full monetary refund, StoreCreditRefund for store credit, or ExchangeRefund when the item is exchanged for the same product. Ignored when returns are not permitted.', $this->cgi, 268, 'zen_cfg_select_option(array(\'FullRefund\', \'StoreCreditRefund\', \'ExchangeRefund\'),'),
                ('Returns - Fee', 'PLUGIN_SUPERDATA_RETURNS_FEE', '0', 'The charge to the customer for returning the product. You can enter a fixed amount or percentage. If you add percentage, the value will be calculated as percentage of the item price.', $this->cgi, 270, null),
                ('Returns - Applicable Country', 'PLUGIN_SUPERDATA_RETURNS_APPLICABLE_COUNTRY', '', '<strong>Required to publish hasMerchantReturnPolicy.</strong> Enter the two-letter ISO country code where this policy applies, for example US. Separate multiple countries with commas.', $this->cgi, 275, null),
                ('Returns - Return Destination Country', 'PLUGIN_SUPERDATA_RETURNS_POLICY_COUNTRY', '', 'Optional two-letter ISO country code where returned products must be sent. This no longer controls whether the return policy is published.', $this->cgi, 280, null),

                ('Custom Product Field - Google Product Category', 'PLUGIN_SUPERDATA_GPC_FIELD', 'products_google_product_category', 'The name of the custom field used in the <strong>products</strong> table for the Google Product Category.', $this->cgi, 285, null),
                ('Custom Product Field - GTIN', 'PLUGIN_SUPERDATA_GTIN_FIELD', 'products_gtin', 'The name of the custom field used in the <strong>products</strong> table for the product-specific code GTIN (EAN, ISBN etc.).', $this->cgi, 290, null),
                ('Default Product Country of Origin', 'PLUGIN_SUPERDATA_COUNTRY_OF_ORIGIN_DEFAULT', '0', 'Standalone fallback used when Google Product Loader is not installed and the product is set to Use store default.', $this->cgi, 291, 'superdata_cfg_pull_down_country_of_origin('),

                ('Custom POS Field - GTIN', 'PLUGIN_SUPERDATA_POS_GTIN_FIELD', 'pos_gtin', 'The name of the custom field used in the <strong>products_options_stock</strong> table for the product-specific GTIN code (EAN, ISBN etc.).', $this->cgi, 295, null),
                ('Custom POS Field - MPN', 'PLUGIN_SUPERDATA_POS_MPN_FIELD', 'pos_mpn', 'The name of the custom field used in the <strong>products_options_stock</strong> table for the manufacturers product code.', $this->cgi, 300, null),

                ('Facebook Default Image: Product (optional)', 'PLUGIN_SUPERDATA_FOG_DEFAULT_PRODUCT_IMAGE', '', 'Fallback image used in Facebook when there is no product image. Enter the full URL or leave blank to use the no-image file defined in the Admin->Images configuration.', $this->cgi, 350, null),
                ('Facebook Default Image: non Product (optional)', 'PLUGIN_SUPERDATA_FOG_DEFAULT_IMAGE', '', 'Fallback image used in Facebook when there is no image on any page other than a product page. Enter the full URL or leave blank to use the logo file defined above.', $this->cgi, 355, null),
                ('Facebook Type - Non Product Page', 'PLUGIN_SUPERDATA_FOG_TYPE_SITE', 'business.business', 'Enter an Open Graph type for your site - non-product pages (<a href=\"https://developers.facebook.com/docs/reference/opengraph/\" target=\"_blank\">Open Graph Types</a>)', $this->cgi, 360, null),
                ('Facebook Type - Product Page', 'PLUGIN_SUPERDATA_FOG_TYPE_PRODUCT', 'product', 'Enter an Open Graph type for your site - product pages (<a href=\"https://developers.facebook.com/docs/reference/opengraph/\" target=\"_blank\">Open Graph Types</a>)', $this->cgi, 365, null),

                ('Twitter Default Image (optional)', 'PLUGIN_SUPERDATA_TWITTER_DEFAULT_IMAGE', '', 'Fallback image used in Twitter when there is no image defined. Enter the full URL.', $this->cgi, 370, null),
                ('Twitter Username', 'PLUGIN_SUPERDATA_TWITTER_USERNAME', '', 'Enter your Twitter username (e.g.: @zencart).', $this->cgi, 375, null),
                ('Twitter Page URL', 'PLUGIN_SUPERDATA_TWITTER_PAGE', '', 'Enter the full URL to your Twitter page (e.g.: https://twitter.com/zencart)', $this->cgi, 380, null),

                ('Google - Default Product Category', 'PLUGIN_SUPERDATA_GOOGLE_PRODUCT_CATEGORY', '', 'Fallback/default Google product category ID (up to 6 digits).<br>Used when a product does not have a GPC defined as an custom product field (e.g. 5613 = Vehicles & Parts, Vehicle Parts & Accessories).<br><a href=\"https://support.google.com/merchants/answer/6324436?hl=en\">Google Product Taxonomy</a>', $this->cgi, 390, null)
                ");

        // Preserve matching values from the former Structured Data plugin.
        $this->executeInstallerSql(
            "UPDATE " . TABLE_CONFIGURATION . " new_config
             INNER JOIN " . TABLE_CONFIGURATION . " old_config
                ON old_config.configuration_key = REPLACE(new_config.configuration_key, 'PLUGIN_SUPERDATA_', 'PLUGIN_SDATA_')
             SET new_config.configuration_value = old_config.configuration_value
             WHERE new_config.configuration_key LIKE 'PLUGIN_SUPERDATA_%'"
        );

        if (!zen_page_key_exists($this->configPageKey)) {
            // -----
            // Register the plugin's configuration page for the admin menus.
            //
            zen_register_admin_page($this->configPageKey, 'BOX_CONFIGURATION_SUPER_DATA', 'FILENAME_CONFIGURATION', "gID=$this->cgi", 'configuration', 'Y');
        }

        return true;
    }

    /**
     * Zen Cart 2.0.x invokes this method without an argument, while Zen Cart
     * 2.1.0 and later supply the previously installed plugin version.
     *
     * @param mixed ...$args
     * @return bool
     */
    protected function executeUpgrade(...$args): bool
    {
        $oldVersion = (string)($args[0] ?? (defined('PLUGIN_SUPERDATA_VERSION') ? 'v' . ltrim((string)PLUGIN_SUPERDATA_VERSION, 'v') : ''));
        $this->cgi = $this->getOrCreateConfigGroupId($this->configGroupTitle, $this->configGroupTitle, null);
        $this->ensureCountryOfOriginField();
        switch ($oldVersion) {
            case "v3.0.0":
                $this->executeInstallerSql("INSERT IGNORE INTO " . TABLE_CONFIGURATION . "
                    (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function)
                    VALUES
                    ('Shipping rate mode', 'PLUGIN_SUPERDATA_SHIPPING_RATE_MODE', 'ZoneTable', '<strong>ZoneTable:</strong> Calculate the rate for this product from the manual tiers.<br><strong>Free:</strong> Publish a 0.00 shipping rate only when shipping is genuinely free.<br><strong>FlatRate:</strong> Publish the exact configured flat rate.', $this->cgi, 133, 'zen_cfg_select_option(array(\'ZoneTable\', \'Free\', \'FlatRate\'),')");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_title = 'Shipping flat rate', configuration_value = '', configuration_description = 'Used only when Shipping rate mode is FlatRate. Enter the exact shipping charge applied to every covered product. Do not enter an average or estimated amount.', sort_order = 135 WHERE configuration_key = 'PLUGIN_SUPERDATA_SHIPPING_RATE'");
                break;

            case "v2.0.0":
                // Add new values
                $this->executeInstallerSql("INSERT IGNORE INTO " . TABLE_CONFIGURATION . "
                    (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function)
                VALUES

                ('Organization Type', 'PLUGIN_SUPERDATA_ORGANIZATION_TYPE', 'Organization', 'If you have a physical store and want to specify it, choose LocalBusiness instead of the generic Organization.', $this->cgi, 8, 'zen_cfg_select_option(array(\'Organization\', \'LocalBusiness\', \'OnlineBusiness\'),'),

                ('LocalBusiness Type', 'PLUGIN_SUPERDATA_LOCAL_BUSINESS_TYPE', 'Store', 'This option is used ONLY if Organization Type is set to LocalBusiness. The list is not complete because there is a large number of options. Choose the one that fits best, or choose Store as a generic option.', $this->cgi, 9, 'zen_cfg_select_option(array(\'Store\', \'ShoppingCenter\', \'BikeStore\', \'BookStore\', \'ClothingStore\', \'ComputerStore\', \'ConvenienceStore\', \'DepartmentStore\', \'ElectronicsStore\', \'Florist\', \'FurnitureStore\', \'GardenStore\', \'GroceryStore\', \'HardwareStore\', \'HobbyShop\', \'HomeGoodsStore\', \'JewelryStore\', \'LiquorStore\', \'MensClothingStore\', \'MobilePhoneStore\', \'MovieRentalStore\', \'MusicStore\', \'OfficeEquipmentStore\', \'OutletStore\', \'PawnShop\', \'PetStore\', \'ShoeStore\', \'SportingGoodsStore\', \'TireShop\', \'ToyStore\', \'WholesaleStore\'),'),

                ('Name (Schema)', 'PLUGIN_SUPERDATA_LOCAL_BUSINESS_NAME', '', 'If you chose LocalBusiness, enter the name (this can be different than your Legal Name).', $this->cgi, 20, null),
                ('Short Description (Schema)', 'PLUGIN_SUPERDATA_DESCRIPTION', '', 'Enter a short description of your business.', $this->cgi, 21, null),
                ('Property Image (Schema)', 'PLUGIN_SUPERDATA_PROPERTY_IMAGE', '', 'If you selected LocalBusiness as your Business Type, you must include a photo of your storefront or building entrance to help customers find you. Best practice is to include 3 photos in different dimensions (1x1, 4x3, 16x9). Example: https://example.com/photos/1x1/photo.jpg, https://example.com/photos/4x3/photo.jpg, https://example.com/photos/16x9/photo.jpg', $this->cgi, 25, null),

                ('Price Range (Schema)', 'PLUGIN_SUPERDATA_PRICE_RANGE', '', 'Use currency symbols to indicate your price range. The standard is a scale from 1 to 4, where 1 stands for inexpensive, 2 for moderate/average, 3 for expensive and 4 means luxury. Example: $$.', $this->cgi, 31, null),

                ('Area Served (Schema-Customer Service, optional)', 'PLUGIN_SUPERDATA_AREA_SERVED', '', 'The geographical region served (<a href=\"https://schema.org/areaServed\" target=\"_blank\">further details here</a>).<br>If omitted, the area is assumed to be global.)', $this->cgi, 85, null),

                ('Hours Available (Schema-Customer Service, optional)', 'PLUGIN_SUPERDATA_HOURS', '', 'Customer service working hours (<a href=\"https://schema.org/hoursAvailable\" target=\"_blank\">further details here</a>).<br>If omitted, it will be skipped.)<br>Supports simple and complex scenarios.<br><strong>REQUIREMENTS:</strong> days are listed first, using 3-letter English abbreviation and separated with a comma. Semicolon is used as delimiter between days and times. Times are entered in 24-hour format with a minus indicating range. Split shifts are separated with a comma. Different rules are separated with a pipe.<br>Examples:<br><strong>Simple:</strong> Mon,Tue,Wed,Thu,Fri;09:00-17:00<br><strong>Weekend different:</strong> Mon,Tue,Wed,Thu,Fri;09:00-17:00|Sat;10:00-14:00<br><strong>Split Shift (Lunch break):</strong> Mon,Tue,Wed,Thu,Fri;09:00-12:00,13:00-17:00<br><strong>Complex:</strong> Mon,Wed,Fri;09:00-17:00|Tue,Thu;09:00-12:00,13:00-17:00|Sat;10:00-12:00', $this->cgi, 90, null),

                ('Returns - Type', 'PLUGIN_SUPERDATA_RETURNS_TYPE', 'FreeReturn', 'The type of fee for returns.', $this->cgi, 265, 'zen_cfg_select_option(array(\'FreeReturn\', \'OriginalShippingFees\', \'RestockingFees\', \'ReturnFeesCustomerResponsibility\', \'ReturnShippingFees\'),')
                ");

                // Update Sort order
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 95 WHERE configuration_key = 'PLUGIN_SUPERDATA_ACCEPTED_PAYMENT_METHODS'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 15 WHERE configuration_key = 'PLUGIN_SUPERDATA_LEGAL_NAME'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 16 WHERE configuration_key = 'PLUGIN_SUPERDATA_DUNS'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 30 WHERE configuration_key = 'PLUGIN_SUPERDATA_LOGO'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 35 WHERE configuration_key = 'PLUGIN_SUPERDATA_STREET_ADDRESS'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 40 WHERE configuration_key = 'PLUGIN_SUPERDATA_LOCALITY'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 45 WHERE configuration_key = 'PLUGIN_SUPERDATA_REGION'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 50 WHERE configuration_key = 'PLUGIN_SUPERDATA_POSTALCODE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 55 WHERE configuration_key = 'PLUGIN_SUPERDATA_COUNTRYNAME'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 60 WHERE configuration_key = 'PLUGIN_SUPERDATA_EMAIL'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 65 WHERE configuration_key = 'PLUGIN_SUPERDATA_TELEPHONE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 70 WHERE configuration_key = 'PLUGIN_SUPERDATA_FAX'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 75 WHERE configuration_key = 'PLUGIN_SUPERDATA_AVAILABLE_LANGUAGE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 80 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_LOCALES'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 100 WHERE configuration_key = 'PLUGIN_SUPERDATA_TAXID'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 105 WHERE configuration_key = 'PLUGIN_SUPERDATA_VATID'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 110 WHERE configuration_key = 'PLUGIN_SUPERDATA_SAMEAS'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 115 WHERE configuration_key = 'PLUGIN_SUPERDATA_ELIGIBLE_REGION'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 120 WHERE configuration_key = 'PLUGIN_SUPERDATA_PRICE_CURRENCY'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 125 WHERE configuration_key = 'PLUGIN_SUPERDATA_DELIVERYLEADTIME'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 130 WHERE configuration_key = 'PLUGIN_SUPERDATA_DELIVERYLEADTIME_OOS'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 135 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_PRODUCT_CONDITION'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 140 WHERE configuration_key = 'PLUGIN_SUPERDATA_DEFAULT_WEIGHT'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 145 WHERE configuration_key = 'PLUGIN_SUPERDATA_OOS_DEFAULT'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 150 WHERE configuration_key = 'PLUGIN_SUPERDATA_OOS_AVAILABILITY_DELAY'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 170 WHERE configuration_key = 'PLUGIN_SUPERDATA_MAX_NAME'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 175 WHERE configuration_key = 'PLUGIN_SUPERDATA_MAX_DESCRIPTION'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 180 WHERE configuration_key = 'PLUGIN_SUPERDATA_REVIEW_DEFAULT_DATE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 185 WHERE configuration_key = 'PLUGIN_SUPERDATA_REVIEW_USE_DEFAULT'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 190 WHERE configuration_key = 'PLUGIN_SUPERDATA_REVIEW_DEFAULT_VALUE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 250 WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_POLICY'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 255 WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_DAYS'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 260 WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_METHOD'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 280 WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_POLICY_COUNTRY'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 285 WHERE configuration_key = 'PLUGIN_SUPERDATA_GPC_FIELD'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 290 WHERE configuration_key = 'PLUGIN_SUPERDATA_GTIN_FIELD'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 295 WHERE configuration_key = 'PLUGIN_SUPERDATA_POS_GTIN_FIELD'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 300 WHERE configuration_key = 'PLUGIN_SUPERDATA_POS_MPN_FIELD'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 350 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_DEFAULT_PRODUCT_IMAGE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 355 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_DEFAULT_IMAGE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 360 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_TYPE_SITE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 365 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_TYPE_PRODUCT'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 370 WHERE configuration_key = 'PLUGIN_SUPERDATA_TWITTER_DEFAULT_IMAGE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 375 WHERE configuration_key = 'PLUGIN_SUPERDATA_TWITTER_USERNAME'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 380 WHERE configuration_key = 'PLUGIN_SUPERDATA_TWITTER_PAGE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 390 WHERE configuration_key = 'PLUGIN_SUPERDATA_GOOGLE_PRODUCT_CATEGORY'");
                // Update Sort order and description
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = 'The charge to the customer for returning the product. You can enter a fixed amount or percentage. If you add percentage, the value will be calculated as percentage of the item price.', sort_order = 270 WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_FEE'");
                $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = 'The country in which the returns policy is applicable (2-char ISO e.g. ES) For worldwide, enter **.', sort_order = 275 WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_APPLICABLE_COUNTRY'");
                break;
        }
        $this->executeInstallerSql("INSERT IGNORE INTO " . TABLE_CONFIGURATION . "
            (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function)
            VALUES
            ('SuperData version', 'PLUGIN_SUPERDATA_VERSION', '3.0.18', 'Installed version. Check <a href=\"https://github.com/mprough/super_data\" target=\"_blank\" rel=\"noopener\">SuperData on GitHub</a> for the newest release because GitHub updates can appear before Zen Cart Plugin Library approval is complete.', $this->cgi, 0, 'zen_cfg_select_option(array(\'3.0.18\'),'),
            ('Returns - Refund Type', 'PLUGIN_SUPERDATA_RETURNS_REFUND_TYPE', 'FullRefund', 'Refund provided for an accepted return. Choose FullRefund for a full monetary refund, StoreCreditRefund for store credit, or ExchangeRefund when the item is exchanged for the same product. Ignored when returns are not permitted.', $this->cgi, 268, 'zen_cfg_select_option(array(\'FullRefund\', \'StoreCreditRefund\', \'ExchangeRefund\'),'),
            ('Default Product Country of Origin', 'PLUGIN_SUPERDATA_COUNTRY_OF_ORIGIN_DEFAULT', '0', 'Standalone fallback used when Google Product Loader is not installed and the product is set to Use store default.', $this->cgi, 291, 'superdata_cfg_pull_down_country_of_origin(')");
        for ($zoneNumber = 1; $zoneNumber <= 5; $zoneNumber++) {
            $zoneDefaultCountry = $zoneNumber === 1 ? 'US' : '';
            $zoneSort = 136 + (($zoneNumber - 1) * 5);
            $this->executeInstallerSql("INSERT IGNORE INTO " . TABLE_CONFIGURATION . "
                (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function)
                VALUES
                ('Zone $zoneNumber rate type', 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_$zoneNumber', 'weight', 'Choose price, weight, or item for this destination table.', $this->cgi, $zoneSort, 'zen_cfg_select_option(array(\'price\', \'weight\', \'item\'),'),
                ('Zone $zoneNumber country', 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_$zoneNumber', '$zoneDefaultCountry', 'Two-letter destination country. Leave blank to disable this zone.', $this->cgi, " . ($zoneSort + 1) . ", null),
                ('Zone $zoneNumber regions', 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_$zoneNumber', '', 'Optional comma-separated state or region codes. Leave blank for the whole country.', $this->cgi, " . ($zoneSort + 2) . ", null),
                ('Zone $zoneNumber rates', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_$zoneNumber', '', 'Inclusive upper-limit:rate pairs, for example 1:5.95,3:7.95,*:9.95.', $this->cgi, " . ($zoneSort + 3) . ", null),
                ('Zone $zoneNumber handling charge', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_$zoneNumber', '0', 'Optional handling charge added to the selected rate.', $this->cgi, " . ($zoneSort + 4) . ", null)");
            $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = $zoneSort WHERE configuration_key = 'PLUGIN_SUPERDATA_ZONE_TABLE_METHOD_$zoneNumber'");
            $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = " . ($zoneSort + 1) . " WHERE configuration_key = 'PLUGIN_SUPERDATA_ZONE_TABLE_COUNTRY_$zoneNumber'");
            $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = " . ($zoneSort + 2) . " WHERE configuration_key = 'PLUGIN_SUPERDATA_ZONE_TABLE_REGIONS_$zoneNumber'");
            $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = " . ($zoneSort + 3) . " WHERE configuration_key = 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES_$zoneNumber'");
            $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = " . ($zoneSort + 4) . " WHERE configuration_key = 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING_$zoneNumber'");
        }
        $this->executeInstallerSql("DELETE FROM " . TABLE_CONFIGURATION . " WHERE configuration_key IN ('PLUGIN_SUPERDATA_ZONE_TABLE_METHOD', 'PLUGIN_SUPERDATA_ZONE_TABLE_RATES', 'PLUGIN_SUPERDATA_ZONE_TABLE_HANDLING')");
        $this->executeInstallerSql("DELETE FROM " . TABLE_CONFIGURATION . " WHERE configuration_key = 'PLUGIN_SUPERDATA_GOOGLE_PUBLISHER'");
        $this->executeInstallerSql("INSERT IGNORE INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function) VALUES ('Product price tax mode', 'PLUGIN_SUPERDATA_PRODUCT_PRICE_TAX_MODE', 'Never', '<strong>Never:</strong> Publish product prices without tax.<br><strong>Always:</strong> Add the tax rate Zen Cart resolves for the visitor.<br><strong>LoggedInTaxZone:</strong> Add tax only for a logged-in customer when Zen Cart resolves a tax rate for that customer\'s country and zone.', $this->cgi, 121, 'zen_cfg_select_option(array(\'Never\', \'Always\', \'LoggedInTaxZone\'),')");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_value = '3.0.18', set_function = 'zen_cfg_select_option(array(\'3.0.18\'),' WHERE configuration_key = 'PLUGIN_SUPERDATA_VERSION'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = 'Installed version. Check <a href=\"https://github.com/mprough/super_data\" target=\"_blank\" rel=\"noopener\">SuperData on GitHub</a> for the newest release because GitHub updates can appear before Zen Cart Plugin Library approval is complete.' WHERE configuration_key = 'PLUGIN_SUPERDATA_VERSION'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_value = 'RateTables' WHERE configuration_key = 'PLUGIN_SUPERDATA_SHIPPING_RATE_MODE' AND configuration_value IN ('MerchantCenter', 'ZoneTable')");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = '<strong>RateTables:</strong> Calculate rates for this product from up to five destination tables.<br><strong>Free:</strong> Publish a 0.00 rate only when shipping is genuinely free.<br><strong>FlatRate:</strong> Publish the exact configured charge for every covered product.', set_function = 'zen_cfg_select_option(array(\'RateTables\', \'Free\', \'FlatRate\'),' WHERE configuration_key = 'PLUGIN_SUPERDATA_SHIPPING_RATE_MODE'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = 'Two-letter ISO 3166-1 destination country, for example US, CA, or GB.' WHERE configuration_key = 'PLUGIN_SUPERDATA_SHIPPING_COUNTRY'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = 'Used only with FlatRate. Enter the exact charge applied to every covered product, for example 5.95.' WHERE configuration_key = 'PLUGIN_SUPERDATA_SHIPPING_RATE'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 161 WHERE configuration_key = 'PLUGIN_SUPERDATA_HANDLING_MIN_DAYS'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 162 WHERE configuration_key = 'PLUGIN_SUPERDATA_HANDLING_MAX_DAYS'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 163 WHERE configuration_key = 'PLUGIN_SUPERDATA_TRANSIT_MIN_DAYS'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 164 WHERE configuration_key = 'PLUGIN_SUPERDATA_TRANSIT_MAX_DAYS'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 165 WHERE configuration_key = 'PLUGIN_SUPERDATA_FOG_PRODUCT_CONDITION'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 166 WHERE configuration_key = 'PLUGIN_SUPERDATA_DEFAULT_WEIGHT'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 167 WHERE configuration_key = 'PLUGIN_SUPERDATA_OOS_DEFAULT'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET sort_order = 168 WHERE configuration_key = 'PLUGIN_SUPERDATA_OOS_AVAILABILITY_DELAY'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_title = 'Business Image (Schema, optional)', configuration_description = 'Image for Organization, OnlineBusiness, OnlineStore, or LocalBusiness markup. Enter one complete image URL or multiple URLs separated by commas. If blank, SuperData uses the configured Logo so the Schema image field is not missing.' WHERE configuration_key = 'PLUGIN_SUPERDATA_PROPERTY_IMAGE'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = '<strong>Required to publish hasMerchantReturnPolicy.</strong> Enter the two-letter ISO country code where this policy applies, for example US. Separate multiple countries with commas.' WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_APPLICABLE_COUNTRY'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_title = 'Returns - Return Destination Country', configuration_description = 'Optional two-letter ISO country code where returned products must be sent. This no longer controls whether the return policy is published.' WHERE configuration_key = 'PLUGIN_SUPERDATA_RETURNS_POLICY_COUNTRY'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_title = 'Organization Type' WHERE configuration_key = 'PLUGIN_SUPERDATA_ORGANIZATION_TYPE'");
        $this->executeInstallerSql("UPDATE " . TABLE_CONFIGURATION . " SET configuration_description = 'Add OfferShippingDetails to every product Offer using the configured destination and delivery times. Disable only when no product shipping information should be published.' WHERE configuration_key = 'PLUGIN_SUPERDATA_SHIPPING_DETAILS_ENABLE'");
        return true;
    }

    /**
     * @return bool
     */
    protected function executeUninstall(): bool
    {
        zen_deregister_admin_pages([$this->configPageKey]);
        $this->deleteConfigurationGroup($this->configGroupTitle, true);
        return true;
    }

    /**
     * Install the shared business-data field without removing it on uninstall.
     */
    protected function ensureCountryOfOriginField(): void
    {
        global $sniffer;

        if (!$sniffer->field_exists(TABLE_PRODUCTS, 'products_country_of_origin')) {
            $this->executeInstallerSql(
                'ALTER TABLE ' . TABLE_PRODUCTS .
                ' ADD COLUMN `products_country_of_origin` INT UNSIGNED NOT NULL DEFAULT 0'
            );
        }
    }

    /**
     * @return bool
     */
    protected function checkForConflictingFiles(): bool
    {
        $files_to_remove = [
            DIR_FS_ADMIN . 'includes/extra_datafiles/plugin_structured_data.php',
            DIR_FS_CATALOG . 'includes/templates/' . $this->template_dir . '/jscript/jscript_plugin_structured_data.php',
        ];

        $error = false;
        foreach ($files_to_remove as $next_file) {
            if (file_exists($next_file)) {
                $error = true;
                $safe_file = str_replace([DIR_FS_ADMIN, DIR_FS_CATALOG], ['[admin_directory]/', ''], $next_file);
                $this->errorContainer->addError(
                    0,
                    sprintf(ERROR_SUPERDATA_CONFLICTING_FILE, $next_file),
                    false,
                    sprintf(ERROR_SUPERDATA_CONFLICTING_FILE, $safe_file)
                );
            }
        }
        return !$error;
    }
}
