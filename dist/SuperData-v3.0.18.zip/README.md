# SuperData 3.0.18 for Zen Cart

SuperData adds JSON-LD structured data and social sharing metadata to Zen Cart ecommerce software. This package contains the Plugin Manager edition for Zen Cart 2.0.x, 2.1.x, and 2.2.x. Use a PHP version supported by your Zen Cart release.

## Install or upgrade

1. Back up the store files and database.
2. Copy the included `zc_plugins` folder into the Zen Cart store root so it merges with the existing `zc_plugins` folder.
3. In Zen Cart admin, go to **Modules > Plugin Manager** and install or upgrade SuperData to **3.0.18**.
4. Check your settings under **Configuration > SuperData**. Clear any relevant caches and verify a category and product page.

## What changed

SuperData skips subcategories with missing or blank names when generating structured data. A missing category name previously could cause a PHP fatal error and stop the parent category page from rendering. Named entries retain their display order and consecutive positions.

This fix requires no catalog repair SQL or collation migration. Restore missing category names separately in the store catalog.

## Uninstall

Use **Modules > Plugin Manager** to uninstall SuperData. This removes the SuperData settings. The shared product Country of Origin field and its values are retained.

## Support and license

Maintained by Melanie Prough, [PRO-Webs, Inc.](https://pro-webs.net/), with contributions from torvista, Zen4All, and ZenExpert.

- [PRO-Webs helpdesk](https://prowebsinc.zohodesk.com/portal/en/newticket)
- [Source and documentation](https://github.com/mprough/super_data)
- [Zen Cart Plugins Library listing](https://www.zen-cart.com/plugins/super-data-markup-vb1984)

See the included GPL license. Installation and configuration are available separately.
